# Tue Oct 27: what to post (day 2 on the App Store)

**Everything in one zip:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct27/TipOut-oct27-posts.zip
On iPhone: open in Safari, download, tap the zip in Files to unzip, then save each file to Photos (Share → Save Video / Save Image). The zip also has this sheet as captions.md.

Theme of the day: splitting the tip pool.

## 1. ~11:30am: Video "Bar split" (IG Reel, TikTok, YouTube Short)
**Download:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct27/V05-bar-split_app-store.mp4
9.7s: "$1,240 tip pool. 4 bartenders. Different hours. Go." → split to the cent → "No calculator. No napkin. No arguments." Ends on the App Store card.

**Instagram caption**
```
Pool night, zero arguments. Enter the night once, add everyone's hours, and TipOut splits card and cash to the cent.
Tag the bartender who always ends up doing the math 👇 TipOut is on the App Store now.
#bartender #bartenderlife #tippool #barlife #serverlife #tipout
```
**Song:** "Nicole Kidman" by ADÉLA (night-out reveal trend). Backup: "DUNG DING BREGA" by 3VILCORE & Pheyx (commercial library).

**TikTok caption**
```
tip pool math at 2am but make it instant 🍸 tag your closing bartender. search "TipOut" on the App Store #bartendertok #tippool #barlife #serverlife #tipout
```
**Song:** "DUNG DING BREGA" by 3VILCORE & Pheyx.

**YouTube Short title**
```
Splitting a $1,240 tip pool to the cent 🍸 #shorts #bartender
```

## 2. Instagram Story (afternoon)
**Download:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct27/S06-oct27-quiz.png
Add a **Quiz** sticker: "What's the real hourly?" A: $45.71, **B: $52.92 (correct)**, C: $49.87.

## 3. ~11pm, after close: AI reel "Tip jar split" (TikTok + YouTube Short)
**Download:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct27/R2-tip-jar-split_app-store.mp4
Two bartenders dump the tip jar, TipOut splits it by hours. Same theme as the morning video, so skip Instagram for this one. **Turn on the AI label.**

**TikTok caption**
```
still splitting the tip jar by hand? 🫙 TipOut splits the pool by hours worked, to the cent. no napkin math, no arguments. search "TipOut" on the App Store (Scenes are AI-generated. App screens are real.) #bartender #bartenderlife #tippool #tipout
```
**YouTube Short title**
```
Splitting the tip jar without the arguments 🫙 #shorts #bartender
```
**Sound:** "DUNG DING BREGA" with the original audio down to about 10%.

## Engagement (10 minutes after each post)
Reply to every comment, pin a top comment with "Search TipOut on the App Store 🐷", answer DMs, and re-share any tags to your Story.

## Where the AI label is
- Instagram: Advanced settings → AI info
- TikTok: More options → AI-generated content
- YouTube: Altered or synthetic content → Yes

# Wed Oct 28: what to post

**Everything in one zip:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct28/TipOut-oct28-posts.zip
On iPhone: open in Safari, download, tap the zip in Files to unzip, then save each file to Photos (Share → Save Video / Save Image). The zip also has this sheet as captions.md.

Theme of the day: watching your paycheck add up.

## 1. ~11:30am: Video "Paycheck" (IG Reel, TikTok, YouTube Short)
**Download:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct28/V06-paycheck_app-store.mp4
8.3s: the home ring fills shift by shift ("+$238 shift") from Day 1 to Day 10 of 14, then "Payday, but make it visible." Ends on the App Store card.

**Instagram caption**
```
Watch your paycheck fill up before payday. Card, cash, tip-out and wages add up on your own pay schedule: weekly, every 2 weeks or twice a month.
On the App Store now.
#serverlife #payday #tips #bartenderlife #restaurantlife #tipout
```
**Song:** "What You Waiting For?" by Gwen Stefani (growth story with on-beat text). Backup: "Mari-Mari" by Benyamin S (commercial library).

**TikTok caption**
```
watching my paycheck fill up shift by shift is weirdly motivating 📈 search "TipOut" on the App Store #serverlife #payday #servertok #tips #tipout
```
**Song:** the Drake "October" sound (celebrate-yourself text videos). Backup: "Mari-Mari" by Benyamin S.

**YouTube Short title**
```
Watch a server's paycheck fill up 📈 #shorts
```

## 2. Instagram Story (afternoon)
**Download:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct28/S07-oct28-poll.png
Add a **Poll** sticker: "Weekly" / "Every 2 weeks" (add "Twice a month" if the 3-option poll shows up).

## 3. ~11pm, after close: "Tip math after close" ad (TikTok, YouTube Short, IG optional)
**Download:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct28/TipOut-ad-9x16_app-store.mp4
23.5s, made from your OpenArt video: stressed tip math after close → snap your checkout → real hourly → bar split → "Your whole paycheck, live" → App Store card. It fits today's paycheck theme. **Turn on the AI label** (the person is AI-generated).

**TikTok caption**
```
no more calculator at 1am 🧮💸 TipOut is on the App Store now, search "TipOut" #servertok #serverlife #bartendersoftiktok #tips #restaurantlife #tipout (scene is AI-generated)
```
**Instagram caption (if you post it there)**
```
Doing tip math after close? 🧮 Snap your checkout and TipOut logs the shift, shows your real hourly, splits the bar to the cent and keeps your whole paycheck live. That's it. 💸
TipOut is on the App Store now. Link in bio.
(Scene is AI-generated.)
#serverlife #bartender #restaurantlife #tips #servertok #tipout
```
**YouTube Short title**
```
Stop doing tip math after close #shorts #serverlife
```
**Sound:** keep the video's own soundtrack.

## Engagement (10 minutes after each post)
Reply to every comment, pin a top comment with "Search TipOut on the App Store 🐷", answer DMs, and re-share any tags to your Story.

## Where the AI label is
- Instagram: Advanced settings → AI info
- TikTok: More options → AI-generated content
- YouTube: Altered or synthetic content → Yes

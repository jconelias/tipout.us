# Wed Oct 28: what to post

**Everything in one zip:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct28/TipOut-oct28-posts.zip
On iPhone: open in Safari, download, tap the zip in Files to unzip, then save each file to Photos (Share → Save Video / Save Image). The zip also has this sheet as captions.md.

Theme of the day: watching your paycheck add up.

## 1. ~11:30am: Video "Paycheck" (IG Reel, TikTok, YouTube Short)
**Download:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct28/V06-paycheck_app-store.mp4
8.3s: the home ring fills shift by shift ("+$238 shift") from Day 1 to Day 10 of 14, then "Payday, but make it visible." Ends on the App Store card.

**Instagram caption**
```
Watch your paycheck fill up before payday. Card, cash, tip-out and wages add up on your own pay schedule: weekly, every 2 weeks or twice a month.
On the App Store now.
#serverlife #payday #tips #bartenderlife #restaurantlife #tipout
```
**Song:** "What You Waiting For?" by Gwen Stefani (growth story with on-beat text). Backup: "Mari-Mari" by Benyamin S (commercial library).

**TikTok caption**
```
watching my paycheck fill up shift by shift is weirdly motivating 📈 search "TipOut" on the App Store #serverlife #payday #servertok #tips #tipout
```
**Song:** the Drake "October" sound (celebrate-yourself text videos). Backup: "Mari-Mari" by Benyamin S.

**YouTube Short title**
```
Watch a server's paycheck fill up 📈 #shorts
```

## 2. Instagram Story (afternoon)
**Download:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct28/S07-oct28-poll.png
Add a **Poll** sticker: "Weekly" / "Every 2 weeks" (add "Twice a month" if the 3-option poll shows up).

## 3. ~11pm, after close: AI reel "Bullet time" (TikTok, YouTube Short, IG optional)
**Download:** https://raw.githubusercontent.com/jconelias/tipout.us/claude/project-thread-fh2aei/downloads/oct28/TipOut-bullet-time-B_app-store.mp4
17s: a server trips mid-rush, time freezes with plates and cash in the air, she catches it all, then real TipOut screens and the App Store card. **Turn on the AI label.**

**TikTok / Instagram caption**
```
POV: the tray goes down but the tips don't 💸 TipOut logs every dollar from every shift, so you always know what you actually made. Free on the App Store, search "TipOut". (Scene is AI-generated. App screens are real.) #serverlife #servertok #waitress #restaurantlife #bartender #tips #bullettime #tipout
```
**YouTube Short title**
```
The tray goes down, the tips don't 💸 #shorts #serverlife
```
**Sound:** keep the clip's own sound, or "Mari-Mari" by Benyamin S with the original audio at about 10%.

## Engagement (10 minutes after each post)
Reply to every comment, pin a top comment with "Search TipOut on the App Store 🐷", answer DMs, and re-share any tags to your Story.

## Where the AI label is
- Instagram: Advanced settings → AI info
- TikTok: More options → AI-generated content
- YouTube: Altered or synthetic content → Yes
